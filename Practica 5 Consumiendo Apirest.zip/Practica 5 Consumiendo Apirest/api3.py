import requests

api_url = "https://dog.ceo/api/breeds/list"

response = requests.get(api_url)

if response.status_code == 200:
    data = response.json()

    razas = data["message"]

    print("Lista de razas de perros:")
    for raza in razas:
        print(f"{raza}")
else:
    print("Error:", response.status_code)
    print(response.text)

