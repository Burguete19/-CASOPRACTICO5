import requests
import matplotlib.pyplot as plt
import matplotlib.image as img


pokemon = input("Introduce el nombre del Pokémon: ")


url = f"https://pokeapi.co/api/v2/pokemon/{pokemon}" 

respuesta = requests.get(url)

if respuesta.status_code != 200:
    print("Pokémon no encontrado")
    exit()

image_url = respuesta.json()['sprites']['front_default']


response = requests.get(image_url)


if response.status_code == 200:

    with open("imagen_descargada.png", "wb") as f:
        f.write(response.content)

    imagen = img.imread("imagen_descargada.png")  
else:
    print(f"Error al descargar la imagen: {response.status_code}")
    exit()
    
plt.title(respuesta.json()['name'])
imgplot = plt.imshow(imagen)
plt.show()


