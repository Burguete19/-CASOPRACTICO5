import requests

character_id = input("Ingrese el ID del personaje: ")
url = f'https://rickandmortyapi.com/api/character/{character_id}'
response = requests.get(url)

if response.status_code == 200:
    character_data = response.json()

    print(f"Nombre: {character_data['name']}")
    print(f"Estado: {character_data['status']}")
    print(f"Especie: {character_data['species']}")
    print(f"Género: {character_data['gender']}")

    image_url = character_data['image']
    image_response = requests.get(image_url)

    if image_response.status_code == 200:
        filename = image_url.split('/')[-1]

        with open(filename, 'wb') as f:
            f.write(image_response.content)

        print(f"Imagen descargada: {filename}")
    else:
        print(f"Error al descargar la imagen: {image_response.status_code}")

else:
    print(f"Error al obtener la información del personaje: {response.status_code}")
